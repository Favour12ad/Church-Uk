import React, { useState } from "react";

const fields = [
  { name: "Men" }, { name: "Women" }, { name: "Boys" }, { name: "Girls" }, { name: "Teens" },
  { name: "First Timer" }, { name: "Born Again" }, { name: "HG Filled" }, { name: "Got Healed" }
];

const App = () => {
  const [formData, setFormData] = useState({
    serviceDate: "",
    serviceType: "Sunday Service",
    attendanceTotal: 0,
    comments: "",
    ...Object.fromEntries(fields.map(f => [f.name.toLowerCase().replace(/ /g, ""), 0]))
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    const newFormData = { ...formData, [name]: value };
    if (["men", "women", "boys", "girls", "teens"].includes(name)) {
      const total = ["men", "women", "boys", "girls", "teens"]
        .map(key => parseInt(newFormData[key]) || 0)
        .reduce((a, b) => a + b, 0);
      newFormData.attendanceTotal = total;
    }
    setFormData(newFormData);
  };

  const handleReset = () => {
    setFormData({
      serviceDate: "",
      serviceType: "Sunday Service",
      attendanceTotal: 0,
      comments: "",
      ...Object.fromEntries(fields.map(f => [f.name.toLowerCase().replace(/ /g, ""), 0]))
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Submitted", formData);
    alert("Form Submitted. Check console for output.");
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-xl font-bold text-center mb-4">Service Attendance Form</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label>Service Date</label>
            <input type="date" name="serviceDate" value={formData.serviceDate} onChange={handleChange} className="w-full border rounded p-2" />
          </div>
          {["Men", "Women", "Boys", "Girls", "Teens"].map(label => (
            <div key={label}>
              <label>{label}</label>
              <input type="number" name={label.toLowerCase()} value={formData[label.toLowerCase()]} onChange={handleChange} className="w-full border rounded p-2" />
            </div>
          ))}
        </div>

        <hr className="my-4" />
        <h3 className="font-semibold">Other Record</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {["First Timer", "Born Again", "HG Filled", "Got Healed"].map(label => (
            <div key={label}>
              <label>{label}</label>
              <input type="number" name={label.toLowerCase().replace(/ /g, "")} value={formData[label.toLowerCase().replace(/ /g, "")]} onChange={handleChange} className="w-full border rounded p-2" />
            </div>
          ))}
          <div>
            <label>Service</label>
            <select name="serviceType" value={formData.serviceType} onChange={handleChange} className="w-full border rounded p-2">
              <option>Sunday Service</option>
              <option>Wednesday Service</option>
              <option>Special Program</option>
            </select>
          </div>
          <div>
            <label>Attendance Total</label>
            <input type="number" name="attendanceTotal" value={formData.attendanceTotal} readOnly className="w-full border rounded p-2 bg-gray-100" />
          </div>
        </div>

        <div>
          <label>Comments</label>
          <textarea name="comments" value={formData.comments} onChange={handleChange} className="w-full border rounded p-2" rows="3" placeholder="Leave a comment..." />
        </div>

        <div className="flex space-x-4">
          <button type="submit" className="bg-black text-white px-4 py-2 rounded">Submit</button>
          <button type="button" onClick={handleReset} className="text-red-600">Reset</button>
        </div>
      </form>
    </div>
  );
};

export default App;